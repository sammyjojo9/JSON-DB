package jsontodb;

public interface JSONObject {

}
