package jsontodb;
import java.io.File;
import java.sql.*;
import org.json.simple.parser.JSONParser;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.ParseException;
import java.io.FileReader;
import com.mongodb.BasicDBObject;
import com.mongodb.BasicDBObjectBuilder;
import com.mongodb.*;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import com.mongodb.Mongo;
import com.mongodb.MongoException;
import com.mongodb.util.JSON;

import java.net.UnknownHostException;

public class opclass {
	public static void main(String args[])
	{
		opclass o=new opclass();
		o.insertJSONtoDB("test.json");
		o.mong();
	}
	public void mong()
	{
		System.out.println("MONGGG");

		 try {
		
		Mongo mongo = new Mongo("127.0.0.1", 27017);

		DB db = mongo.getDB("yourdb");
		
		DBCollection collection = db.getCollection("dummyColl");
		System.out.println("JSON parse example...");
		
		String json = "{\r\n" + 
				"	\"quiz\": {\r\n" + 
				"		\"sport\": {\r\n" + 
				"			\"q1\": {\r\n" + 
				"				\"question\": \"Which one is correct team name in NBA?\",\r\n" + 
				"				\"options\": [\r\n" + 
				"							\"New York Bulls\",\r\n" + 
				"							\"Los Angeles Kings\",\r\n" + 
				"							\"Golden State Warriros\",\r\n" + 
				"							\"Huston Rocket\"\r\n" + 
				"							],\r\n" + 
				"				\"answer\": \"Huston Rocket\"\r\n" + 
				"				}\r\n" + 
				"			},\r\n" + 
				"		\"maths\": {\r\n" + 
				"				\"q1\": {\r\n" + 
				"				\"question\": \"5 + 7 = ?\",\r\n" + 
				"				\"options\": [\r\n" + 
				"							\"10\",\r\n" + 
				"							\"11\",\r\n" + 
				"							\"12\",\r\n" + 
				"							\"13\"\r\n" + 
				"							],\r\n" + 
				"				\"answer\": \"12\"\r\n" + 
				"						},\r\n" + 
				"				\"q2\": {\r\n" + 
				"				\"question\": \"12 - 8 = ?\",\r\n" + 
				"				\"options\": [\r\n" + 
				"							\"1\",\r\n" + 
				"							\"2\",\r\n" + 
				"							\"3\",\r\n" + 
				"							\"4\"		\r\n" + 
				"							],\r\n" + 
				"				\"answer\": \"4\"\r\n" + 
				"				}\r\n" + 
				"				}\r\n" + 
				"			}\r\n" + 
				"		}\r\n" + 
				"";

		DBObject dbObject = (DBObject)JSON.parse(json);
				System.out.println("HEYy");
		collection.insert((DBObject)dbObject);
		System.out.println("HEYy23434");
		
		DBCursor cursorDocJSON = collection.find();
		while (cursorDocJSON.hasNext()) {
			System.out.println(cursorDocJSON.next());
		}
		//collection.remove(new BasicDBObject());
		
		    } catch (UnknownHostException e) {
			e.printStackTrace();
		    }
		 catch (MongoException e) {
			e.printStackTrace();
		    }

		
	}
	public int insertJSONtoDB(String fpath) {
	    System.out.println("hellololo");
	    try {
	        Class.forName("com.mysql.jdbc.Driver");
	        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/jtodb", "root", "sameer");
	        PreparedStatement preparedStatement1 = con.prepareStatement("insert into  subject values ( ?, ?)");
	    	 PreparedStatement preparedStatement2 = con.prepareStatement("insert into  question values ( ?, ?, ?, ?, ? ,?, ?)");
	        JSONParser parser = new JSONParser();
	        Object obj = parser.parse(new FileReader("test.json")); 
	        JSONObject jsonObject = (JSONObject) obj;
	        JSONObject  quiz = (JSONObject) jsonObject.get("quiz");
	       
	        JSONObject   sp = (JSONObject) quiz.get("sport");
	        JSONObject   q = (JSONObject) sp.get("q1");
	     
	        String pr = (String) q.get("question");
	        
	        System.out.println(pr);
	        
	    }catch (Exception e) {
	        e.printStackTrace();
	    } 
return 0;
}
}